import './App.css';
import Calculator from './components/calculator';

function App() {
  return (
    <div>
      <h1>hello</h1>
      <Calculator/>
    </div>
  );
}

export default App;
